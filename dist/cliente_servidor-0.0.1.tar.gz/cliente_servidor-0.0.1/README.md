# Comunicação entre servidor / cliente

Este projeto faz a comunicação entre servidor e cliente utilizando o protocolo UDP

## Tecnologias

Python  
Biblioteca: socket